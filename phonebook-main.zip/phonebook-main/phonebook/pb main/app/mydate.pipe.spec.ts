import { MydatePipe } from './mydate.pipe';

describe('MydatePipe', () => {
  it('create an instance', () => {
    const pipe = new MydatePipe();
    expect(pipe).toBeTruthy();
  });
});

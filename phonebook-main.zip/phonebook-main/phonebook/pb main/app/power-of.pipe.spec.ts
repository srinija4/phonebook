import { PowerOfPipe } from './power-of.pipe';

describe('PoweOfPipe', () => {
  it('create an instance', () => {
    const pipe = new PowerOfPipe();
    expect(pipe).toBeTruthy();
  });
});
